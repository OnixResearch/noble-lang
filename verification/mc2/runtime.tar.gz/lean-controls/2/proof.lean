-- noble-evidence v1 statement 3800153430775572595
{"certified":true,"construction":"Certified"}