//! The checking environment: one scheme per definition, its behavior kind,
//! its external dependency data, the user-declared schemas, and the
//! supplied effect-identity table.
//!
//! Contracts are rank-1 schemes; the bootstrap table lives in `bootstrap`.

pub mod bootstrap;

/// Identity of one environment definition.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Definition(pub u32);

/// The reserved identity of the resource-free `test.emit` effect.
pub const TEST_EMIT: crate::types::EffId = crate::types::EffId(0);

/// The reserved resource kind used by negative eligibility fixtures.
pub const FIXTURE_RESOURCE: crate::types::ResourceKind = crate::types::ResourceKind(0);

/// Identity of one user-declared schema in external environment data.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SchemaId(pub u32);

/// What a definition's contract constrains beyond its scheme.
///
/// The extracted constructors carry a `Behavior` suffix: `Unit` would
/// otherwise shadow Lean's own `Unit` inside every declaration named
/// `contracts.Behavior.*`, where this type's instances live.
#[charon::variants_suffix("Behavior")]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Behavior {
    /// `dup`: requires `Data` on its value variable.
    Dup,
    /// `drop`: requires `Data` on its value variable.
    Drop,
    /// `swap`.
    Swap,
    /// `dip`.
    Dip,
    /// `+`, `-`, or `*`; wrapping `I64`.
    Arith,
    /// `=`: `I64` equality yielding `Bool`.
    Equals,
    /// `quote`: requires `Data` on its captured variable.
    Quote,
    /// `compose`.
    Compose,
    /// `run`.
    Run,
    /// `reflect`.
    Reflect,
    /// `unit`.
    Unit,
    /// `pair`.
    Pair,
    /// `unpair`.
    Unpair,
    /// `inl`.
    Inl,
    /// `inr`.
    Inr,
    /// `case`.
    Case,
    /// `if`.
    If,
    /// `nil`.
    Nil,
    /// `cons`.
    Cons,
    /// `list.case`.
    ListCase,
    /// The supplied `test.emit` operation.
    TestEmit,
    /// An environment-supplied named definition with no extra constraint.
    Named,
}

/// One user-declared schema in external environment data.
///
/// A declaration that names itself — a recursive schema — is unsupported
/// (B-CHECK-02) and rejected during preflight; a non-recursive declaration
/// is still validated as a scheme before any candidate body is checked.
#[derive(Clone, Debug)]
pub struct SchemaDecl {
    /// The declared schema's identity.
    pub id: SchemaId,
    /// The declared contract.
    pub scheme: crate::words::Scheme,
    /// Whether the declaration names itself.
    pub recursive: bool,
}

/// The checking environment.
#[derive(Clone, Debug)]
pub struct Env {
    /// Schemes indexed by `Definition`.
    pub defs: alloc::vec::Vec<crate::words::Scheme>,
    /// Behavior kinds indexed by `Definition`.
    pub kinds: alloc::vec::Vec<Behavior>,
    /// Per-definition dependency lists from external environment data; the
    /// bootstrap table declares none, and a missing entry means none.
    pub deps: alloc::vec::Vec<alloc::vec::Vec<Definition>>,
    /// User-declared schemas from external environment data.
    pub schemas: alloc::vec::Vec<SchemaDecl>,
    /// Effect identities this environment provides; `TEST_EMIT` is first.
    pub effects: alloc::vec::Vec<crate::types::EffId>,
}

impl Env {
    /// The scheme of a definition.
    pub fn scheme(&self, def: Definition) -> Option<&crate::words::Scheme> {
        match index(def) {
            Some(index) => self.defs.get(index),
            None => None,
        }
    }

    /// The behavior of a definition.
    pub fn kind(&self, def: Definition) -> Option<Behavior> {
        match index(def) {
            Some(index) => self.kinds.get(index).copied(),
            None => None,
        }
    }

    /// Whether the environment provides this effect identity.
    pub fn knows_effect(&self, id: crate::types::EffId) -> bool {
        let mut index = 0;
        let mut is_known = false;
        while index < self.effects.len() {
            if self.effects[index] == id {
                is_known = true;
                break;
            }
            index += 1;
        }
        is_known
    }

    /// Number of definitions.
    pub fn len(&self) -> Option<u64> {
        u64::try_from(self.defs.len()).ok()
    }

    /// Whether the environment has no definitions.
    pub fn is_empty(&self) -> bool {
        self.defs.len() == 0
    }
}

fn index(def: Definition) -> Option<usize> {
    usize::try_from(def.0).ok()
}

/// Build the bootstrap environment with the fixed v1 contract table.
#[expect(
    tigerstyle::assertion_density,
    reason = "Owner: noble-maintainers; environment validates every bootstrap scheme before constructing its parallel definition/kind/dependency tables and returns the first Defect; assertions would change this fallible construction contract."
)]
pub fn environment() -> Result<Env, crate::shapes::Defect> {
    let table = bootstrap::data::table();
    let mut defs: alloc::vec::Vec<crate::words::Scheme> = alloc::vec::Vec::with_capacity(32);
    let mut kinds: alloc::vec::Vec<Behavior> = alloc::vec::Vec::with_capacity(32);
    let mut deps: alloc::vec::Vec<alloc::vec::Vec<Definition>> = alloc::vec::Vec::with_capacity(32);
    let mut index = 0;
    let mut defect: Option<crate::shapes::Defect> = None;
    while index < table.len() {
        match table[index].1.validate() {
            Ok(()) => {
                kinds.push(table[index].0);
                index += 1;
            }
            Err(problem) => {
                defect = Some(problem);
                break;
            }
        }
    }
    if let Some(problem) = defect {
        return Err(problem);
    }
    let mut table_index = 0;
    while table_index < table.len() {
        defs.push(table[table_index].1.clone());
        #[expect(
            tigerstyle::allocation_in_loop,
            reason = "Owner: noble-maintainers; Vec::new allocates no storage and records the bootstrap definition's empty dependency list; reassess if this changes to a nonzero-capacity constructor."
        )]
        deps.push(alloc::vec::Vec::new());
        table_index += 1;
    }
    Ok(Env {
        defs,
        kinds,
        deps,
        schemas: alloc::vec::Vec::new(),
        effects: alloc::vec![TEST_EMIT],
    })
}
