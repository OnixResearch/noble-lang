(module (type $sig (func (result i32))) (func $f (type $sig) i32.const 7) (elem declare func $f) (func (export "probe") (result i32) ref.func $f call_ref $sig))
