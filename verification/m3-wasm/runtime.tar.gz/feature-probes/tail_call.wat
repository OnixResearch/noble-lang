(module (func $f (result i32) i32.const 7) (func (export "probe") (result i32) return_call $f))
