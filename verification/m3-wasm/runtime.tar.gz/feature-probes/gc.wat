(module (type $box (struct (field i32))) (func (export "probe") (result i32) i32.const 7 struct.new $box struct.get $box 0))
