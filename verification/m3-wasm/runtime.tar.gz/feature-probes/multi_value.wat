(module (func (export "probe") (result i32 i32) i32.const 1 i32.const 2))
