# WIT, Component Model, and WASI Integration Profile

Document: SPEC-W001  
Revision: 0.1.0-draft.1  
Date: 2026-09-12  
Project: noble  
Status: Working specification; architectural commitments selected, implementation and conformance remain open  
Depends on: SPEC-0001, SPEC-S001, SPEC-V001

## 1. Purpose

This specification makes the WebAssembly Component Model a first-class Noble platform boundary without making Noble's internal language WIT-shaped.

The selected architecture is:

```text
Noble source semantics
    Program<S,T,e>, stack types, effects, resources
                 |
                 | checked specialization/adaptation
                 v
WIT packages and worlds
    external component contracts
                 |
                 v
Component Model / Canonical ABI
                 |
                 v
Wasm components + WASI host profiles
```

The normative distinction is:

> **WIT is Noble's standard external interface language. WASI is Noble's preferred standard host-interface family. Noble's internal types, effects, programs-as-data semantics, and authority model remain richer and independent.**

The standard component profile targets the stable WASI 0.3 family. An implementation MAY support WASI 0.2 through an explicit compatibility profile. Exact package versions and runtime/toolchain versions are build inputs and MUST be pinned for reproducible artifacts.

## 2. Architectural position

**WI-ARCH-01.** A conforming `Component-Draft` implementation SHALL treat WebAssembly components, rather than unadorned core modules, as the primary portable deployment/interoperability artifact. Internal compiler stages MAY use core Wasm modules, and an explicitly named lower-level profile MAY expose them, but that profile is not the standard Noble component contract.

**WI-ARCH-02.** WIT SHALL be the standard language for describing Noble component imports, exports, resource interfaces, and host-facing component contracts. Noble MUST NOT invent a parallel general-purpose component IDL where WIT can express the required contract.

**WI-ARCH-03.** WIT is not Noble's internal type system. It MUST NOT constrain the semantics of `Program<S,T,e>`, stack-tail polymorphism, effect bounds, recipes, syntax reflection, definition identity, proof evidence, or other Noble-only concepts merely because those concepts lack direct WIT equivalents.

**WI-ARCH-04.** A WIT world describes a component boundary: the functionality a component requires and provides. It does not specify the component's internal behavior, purity, Noble effect bound, proof status, or concrete runtime authority.

## 3. WIT package ingestion and generated bindings

**WI-WIT-01.** The Noble compiler SHALL accept versioned WIT packages/worlds as compiler inputs and generate typed Noble bindings without requiring the user to hand-write equivalent host declarations.

**WI-WIT-02.** Generated bindings MUST preserve the complete externally visible WIT type distinction. Where the Noble kernel has no identical scalar or aggregate type, the binding layer MUST introduce an exact declared/boundary type or checked conversion; it MUST NOT silently narrow, wrap, reinterpret, or otherwise lose information.

**WI-WIT-03.** For a WIT function with ordered parameters `A1 ... An` and ordered results `B1 ... Bm`, a generated Noble import word has the schematic stack interface:

```text
S A1 ... An -- S B1 ... Bm ! {WitOpId}
```

where `WitOpId` identifies the exact versioned WIT package, interface, and function. The actual generated effect bound MAY be more specific under a reviewed profile, but MUST NOT be narrower merely because WIT has no effect annotation.

**WI-WIT-04.** A WIT import MUST be treated as potentially effectful by default. A WIT function signature alone MUST NOT be interpreted as proof of purity, determinism, termination, authorization, or absence of external interaction.

**WI-WIT-05.** A Noble export implementing a WIT function MUST have a closed, WIT-lowerable external interface. The component adapter SHALL invoke that program against an isolated adapter stack containing only the declared parameters and SHALL validate that its normal results match the declared WIT result contract. An ambient Noble stack tail MUST NOT cross a component boundary implicitly.

**WI-WIT-06.** Values crossing the component boundary MUST be validated and lowered/lifted according to the selected Component Model/Canonical ABI contract. An implementation MUST NOT expose internal addresses, closure pointers, stack locations, or unspecified language representations as WIT values.

## 4. WIT resources and Noble ownership

**WI-RES-01.** An owned WIT resource handle SHALL map to a Noble move-only resource obligation. It MUST NOT satisfy `Data` or `Capture` merely because the WIT representation is handle-shaped.

**WI-RES-02.** A borrowed WIT resource SHALL be represented as a scoped non-owning boundary value whose lifetime cannot escape the adapter call or declared borrow scope. It MUST NOT be captured, persisted, serialized, stored beyond its scope, or released as though it were owned. This requirement does not introduce a general Rust-style borrow checker into ordinary Noble code.

**WI-RES-03.** WIT resource type identity, ownership mode, component instance/context, and host validation MUST participate in resource-handle validation. Integers, bytes, external IDs, or stale handles MUST NOT be accepted as live resources solely because they have a compatible machine representation.

**WI-RES-04.** Resource lowering MUST preserve the existing Noble normal-path and abnormal-cleanup obligations. A Component Model adapter MUST NOT weaken SPEC-0001's move-only ownership rules.

## 5. Worlds, effects, and authority

**WI-WORLD-01.** The selected WIT world and exact imported/exported interface versions SHALL be explicit compilation inputs and SHALL participate in the build key. Replacing an interface version or world is not an invisible linker detail.

**WI-WORLD-02.** The compiler SHALL reject an export whose Noble interface cannot be soundly lowered to the selected WIT contract. It MUST NOT satisfy an incompatible WIT export through `Any`, unchecked casts, implicit resource laundering, or runtime operand guessing.

**WI-AUTH-01.** WIT import availability and a Noble effect bound are not, by themselves, authority grants. Runtime authority SHALL remain controlled by the linked host/component implementation, resource/capability values, and host policy. Some imported functions may themselves convey ambient authority; such authority MUST be documented by the host profile and is not created by the Noble type checker.

**WI-AUTH-02.** Standard Noble profiles SHOULD prefer capability-scoped/resource-scoped WIT and WASI interfaces over ambient global authority where the ecosystem interface permits it.

**WI-AUTH-03.** WIT package/interface/function identity MAY supply stable names for Noble host-operation/effect identities. Such identities describe the operation contract, not the caller's permission to perform it.

## 6. WASI as the standard host-interface family

**WI-WASI-01.** The standard Noble host profile SHALL use stable WASI interfaces where a stable WASI interface adequately represents the desired host capability. A Noble-specific duplicate filesystem, clock, random, socket, HTTP, CLI, or similar interface SHOULD NOT be standardized without a documented semantic reason.

**WI-WASI-02.** The preferred standard host profile SHALL target the stable WASI 0.3 family. Exact WIT/WASI package patch versions MUST be pinned in a reproducible build/profile and MUST participate in compatibility checks and build identity.

**WI-WASI-03.** WASI 0.2 support MAY be provided as an explicitly named compatibility profile or adapter. A compiler/runtime MUST NOT silently reinterpret a 0.2 component as 0.3, or vice versa, without a documented compatibility layer.

**WI-WASI-04.** Noble-specific platform facilities that cross a component boundary SHOULD themselves be expressed as versioned WIT packages so Rust, Noble, and other Component Model languages can participate without language-specific ABI agreements.

## 7. Native async, streams, and futures

WASI 0.3 and the Component Model provide native cross-component `async func`, `stream<T>`, and `future<T>` primitives. Noble adopts these as its standard *component-boundary* async ABI. This choice does not add `async` or `await` expression forms to Noble.

**WI-ASYNC-01.** A WIT `async func` imported into Noble SHALL be callable through direct-style Noble code. The runtime MAY suspend and resume the invocation according to the Component Model async ABI; source-level sequential evaluation order MUST remain preserved.

**WI-ASYNC-02.** Suspension of an async import MUST NOT imply concurrency of subsequent sequential Noble words, speculative execution, retry, transactionality, or reordering.

**WI-ASYNC-03.** WIT `stream<T>` and `future<T>` SHALL be represented by typed profile-level Noble values with explicit completion/cancellation/error semantics. They are not additional expression forms.

**WI-ASYNC-04.** Until duplication/capture semantics are proven and standardized for a particular async value, `stream<T>` and `future<T>` boundary values SHALL conservatively be treated as non-`Data` and non-`Capture` when they carry live runtime state.

**WI-ASYNC-05.** The standard async profile MUST specify cancellation propagation, outstanding resource ownership, completion errors, quotas/backpressure where applicable, and cleanup after abnormal termination. Native Component Model async is an ABI mechanism, not a complete concurrency policy.

## 8. `Program` values and portable code

**WI-PROG-01.** Noble `Program<S,T,e>` is not automatically a WIT function value, resource, or closure. A component boundary MUST NOT export an internal program as a raw address or unspecified handle.

**WI-PROG-02.** Transporting a Noble program across a component, process, or network boundary remains an explicit portable-code/package problem. Such transport MUST preserve recipe/interface/dependency identity, validation/preparation requirements, capture eligibility, and destination-side authorization.

**WI-PROG-03.** A concrete WIT resource interface for prepared Noble programs MAY be standardized later, but it MUST specify ownership, interface specialization, recipe/provenance binding, lifecycle, and authorization independently of the internal `Program<S,T,e>` representation.

## 9. Syndicate, Preserves, and component boundaries

**WI-SYN-01.** Syndicate/Synit remains the standard Noble concurrency/service model. Where the Syndicate layer crosses Component Model boundaries, its host/component operations SHOULD be exposed through versioned WIT packages rather than bespoke native ABIs.

**WI-SYN-02.** Preserves and WIT are complementary. Preserves is the default protocol/schema representation for Syndicate conversational data; WIT defines component interfaces, resources, and ABI-visible operations. A Preserves value does not become a WIT resource/capability without an explicit validated adapter.

**WI-SYN-03.** A componentized Syndicate implementation MUST preserve the standard concurrency profile's scope, assertion-lifetime, isolation, capability, and hostile-input safety requirements across the WIT boundary.

## 10. Versioning, identity, and reproducibility

**WI-ID-01.** Exact WIT package/world/interface versions, Component Model feature profile, WASI profile, adapters, and relevant runtime/compiler configuration SHALL participate in the `BuildKey` when they can affect generated artifacts or observable boundary semantics.

**WI-ID-02.** WIT or WASI package identity MUST NOT replace `DefinitionId` or `ProgramValueId`. Component interface identity and Noble program identity answer different questions.

**WI-ID-03.** Upgrading a WIT/WASI dependency MUST NOT silently mutate a previously prepared Noble program or running component. Rebuilding against a changed boundary creates a new build context and, where emitted bytes differ, a new artifact identity.

## 11. Safety and trust boundary

**WI-SAFE-01.** WIT/component decoding, lifting/lowering, resource-table access, host callbacks, and native adapter entry points are hostile or semi-trusted boundaries under SPEC-S001. Public wrappers MUST validate every precondition not already established by an independently verified caller.

**WI-SAFE-02.** A valid Wasm component or valid WIT world does not prove that Noble recipe metadata, effect metadata, proof evidence, resource authority, or semantic provenance is truthful. Loading/admission MUST preserve SPEC-0001's separate validation and trust checks.

**WI-SAFE-03.** The standard Noble-safe claim for the Component profile requires tests and assurance covering WIT type mapping, resource ownership/borrows, malformed component values, wrong-context handles, import/export mismatch, async cancellation/cleanup, and the selected loader/linker boundary.

## 12. Conformance scenarios

The accompanying `conformance/wit-wasi-cases.json` contains expected scenarios. All scenarios in this revision are `not-run` until executed against an implementation.

A conforming Component profile must cover at least:

- importing a WIT function as a statically typed Noble word;
- rejecting a Noble export with an incompatible stack/result interface;
- preserving exact WIT numeric/data distinctions without lossy implicit conversion;
- owned WIT resources remaining move-only/noncapturable;
- borrowed WIT resources being rejected if they escape scope;
- forged or stale resource handles being rejected;
- an imported WIT function contributing a conservative effect requirement;
- lack of runtime authority despite a type-correct effect/import when the host does not grant it;
- native async suspension preserving sequential Noble ordering;
- typed `stream<T>`/`future<T>` boundary handling and cleanup;
- explicit WASI 0.2 compatibility rather than silent version substitution;
- `Program<S,T,e>` not being exported as a raw generic WIT function/address;
- exact WIT/WASI versions affecting build identity;
- Preserves protocol values requiring explicit conversion at WIT resource/capability boundaries.

## 13. Release gates and open work

Before the standard Component profile can be called stable, the project must complete:

| ID | Deliverable |
|---|---|
| OW-01 | Complete lossless WIT-to-Noble type mapping, including exact integer/floating widths and aggregate/schema identities |
| OW-02 | Owned/borrowed WIT resource adapter design and checker rules |
| OW-03 | Concrete WIT world import/export compiler pipeline and generated-binding tests |
| OW-04 | Component Model/Canonical ABI lowering and loader/linker implementation |
| OW-05 | WASI 0.3 profile package/version matrix with pinned Wasmtime/tooling compatibility |
| OW-06 | Native async/stream/future runtime semantics, cancellation, backpressure, and resource accounting |
| OW-07 | Syndicate/Synit WIT package boundary and Preserves conversion profile |
| OW-08 | Executed cross-language interoperability suite with at least one independently implemented Component Model language/toolchain |
| OW-09 | Safety/trust correspondence for public wrappers, resource tables, lifting/lowering, and component loading |
| OW-10 | Source/recipe-to-component correspondence evidence appropriate to advertised verification claims |

## 14. External reference status

The architectural facts used by this revision were checked against first-party documentation on 2026-09-12:

- WIT worlds describe a component's imports and exports and define its external contract: <https://component-model.bytecodealliance.org/design/wit.html> and <https://component-model.bytecodealliance.org/design/worlds.html>
- WASI 0.3 is the current stable WASI family; 0.3 adds Component Model native async primitives `async func`, `stream<T>`, and `future<T>`: <https://wasi.dev/releases> and <https://wasi.dev/releases/wasi-p3>
- Component Model native async is documented at <https://component-model.bytecodealliance.org/design/async.html>

These references establish ecosystem mechanisms and current release status. Noble's type mapping, effect treatment, ownership rules, standard-profile policy, and safety requirements above are Noble-specific design decisions.
